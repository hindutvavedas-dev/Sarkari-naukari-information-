package com.exammate.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

private const val DEFAULT_API_URL = "https://YOUR-BACKEND.example.com/api/ask"

data class ChatMessage(val text: String, val user: Boolean, val sources: List<String> = emptyList())

class ExamViewModel : ViewModel() {
    var messages by mutableStateOf(listOf(ChatMessage("Hi! Main ExamMate hoon. Exam ka naam ya question bhejo — cutoff, dates, syllabus, pattern aur vacancies ke liye main concise answer dunga.", false)))
        private set
    var loading by mutableStateOf(false)
        private set
    var hinglish by mutableStateOf(true)
    var apiUrl by mutableStateOf(DEFAULT_API_URL)

    fun ask(query: String) {
        if (query.isBlank() || loading) return
        messages = messages + ChatMessage(query.trim(), true)
        loading = true
        viewModelScope.launch {
            val result = runCatching { Backend.ask(apiUrl, query.trim(), if (hinglish) "hinglish" else "english") }
            result.onSuccess { messages = messages + ChatMessage(it.answer, false, it.sources) }
                .onFailure { messages = messages + ChatMessage("Backend connect nahi hua. Settings mein API URL set karo.\n\n${it.message ?: "Unknown error"}", false) }
            loading = false
        }
    }
}

data class Answer(val answer: String, val sources: List<String>)
object Backend {
    private val client = OkHttpClient()
    fun ask(url: String, query: String, language: String): Answer {
        require(!url.contains("YOUR-BACKEND")) { "API URL configure karo" }
        val json = JSONObject().apply { put("query", query); put("language", language); put("concise", true) }
        val body = json.toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(url).post(body).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Server error ${r.code}")
            val obj = JSONObject(r.body?.string() ?: "{}")
            val arr = obj.optJSONArray("sources")
            val sources = buildList { if (arr != null) for (i in 0 until arr.length()) add(arr.optString(i)) }
            return Answer(obj.optString("answer", "No answer received"), sources)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ExamMateApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ExamMateApp(vm: ExamViewModel = viewModel()) {
    var query by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("ExamMate", fontWeight = FontWeight.Bold) }, actions = {
            TextButton(onClick = { vm.hinglish = !vm.hinglish }) { Text(if (vm.hinglish) "Hinglish" else "English") }
            TextButton(onClick = { showSettings = true }) { Text("⚙") }
        }) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)) {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vm.messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.user) Arrangement.End else Arrangement.Start) {
                            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 340.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(msg.text)
                                    msg.sources.forEach { s -> Text("Source: $s", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
                                }
                            }
                        }
                    }
                    if (vm.loading) item { Text("Checking latest information…", modifier = Modifier.padding(8.dp)) }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    OutlinedTextField(query, { query = it }, Modifier.weight(1f), placeholder = { Text("e.g. SSC CHSL last cutoff?") }, maxLines = 3)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.ask(query); query = "" }, enabled = query.isNotBlank() && !vm.loading) { Text("Ask") }
                }
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Backend Settings") }, text = {
            Column { Text("Your backend endpoint (no API key in APK):"); Spacer(Modifier.height(8.dp)); OutlinedTextField(vm.apiUrl, { vm.apiUrl = it }, singleLine = true) }
        }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Save") } })
    }
}
